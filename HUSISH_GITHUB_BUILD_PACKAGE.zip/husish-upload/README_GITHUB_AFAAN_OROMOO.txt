HUSISH ELECTRONICS CENTER — GITHUB BUILD

Faayilota lama kana repository GitHub kee keessatti galchi:
1. HUSISH_ELECTRONICS_CENTER_source_fixed.zip — root folder repository keessatti.
2. .github/workflows/build-apk.yml — maqaa fi folder isaa akkuma jirutti.

Tarkaanfii bilbila irraa:
1. GitHub repository kee bani.
2. Add file > Upload files filadhu.
3. ZIP source galchi; commit changes godhi.
4. Folder .github/workflows keessa faayila build-apk.yml uumi (yoo package kana keessaa faayila baaftee upload gootu).
5. Actions > Build HUSISH Android APK > Run workflow fili.
6. Yoo workflow milkaa'e, artifact HUSISH-ELECTRONICS-CENTER-debug-APK buusi.
7. ZIP artifact keessaa app-debug.apk baasi; bilbila irratti qoradhu.

Hubachiisa:
- APK amma ijaaramee hin jiru; GitHub Actions irratti ijaarsa eegaa jira.
- Source keessatti Room database bilbila irratti kuusa; hojii bu'uuraa offline dha.
- Backup/restore ammayyuu hin dabalamin; data hojii dhugaa dura qorannoo godhi.
- APK debug kun Play Store release miti.
